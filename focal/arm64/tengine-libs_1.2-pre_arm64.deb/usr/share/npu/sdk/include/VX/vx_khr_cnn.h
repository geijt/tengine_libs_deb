#ifndef _VX_KHR_CNN_H_
#define _VX_KHR_CNN_H_

#define OPENVX_KHR_CNN   "vx_khr_cnn"

#include <VX/vx_khr_nn.h>

#endif
